from astral_core import check_market_condition
from utils import send_message
import time

if __name__ == '__main__':
    while True:
        try:
            message = check_market_condition()
            if message:
                send_message(message)
        except Exception as e:
            send_message(f"⚠️ 오류 발생: {e}")
        time.sleep(10)  # 10초마다 반복
