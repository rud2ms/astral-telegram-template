import requests

def check_market_condition():
    # 샘플 API 호출 (Bitget 자산 조회 예시)
    try:
        # 여기에 Bitget API 요청 코드를 넣어주세요
        # 예시: if 자산 > 100 USDT: return "진입 조건 감지됨"
        return "🔍 전략 조건 테스트 메시지 전송됨"
    except Exception as e:
        return f"전략 분석 중 오류: {e}"
